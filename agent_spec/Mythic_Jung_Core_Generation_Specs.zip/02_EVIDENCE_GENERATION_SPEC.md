# Evidence Generation Spec

Evidence is structured attribution, not explanation.

Rules:
- Every major section must have evidence
- Evidence includes:
  - targetPath
  - characterRefs
  - assessmentRefs
- Neutral, factual tone
