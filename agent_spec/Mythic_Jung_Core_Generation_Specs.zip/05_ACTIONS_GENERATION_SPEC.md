# Actions Generation Spec

Subcategories:
- Situation Blocks
- Guiding Question

Each situation block includes:
- Situation
- Aligned Responses
- Be Wary Of

Rules:
- Concrete scenarios
- Principle-based guidance
