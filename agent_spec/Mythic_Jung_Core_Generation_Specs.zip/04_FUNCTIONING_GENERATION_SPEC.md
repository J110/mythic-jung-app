# Functioning Generation Spec

Subcategories:
- Core Traits
- Symbolic Essence
- Narrative Arc
- Redemption Arc
- Costs & Compensations
- Alignment Indicators

Rules:
- Use observable behaviors
- Frame time and movement
