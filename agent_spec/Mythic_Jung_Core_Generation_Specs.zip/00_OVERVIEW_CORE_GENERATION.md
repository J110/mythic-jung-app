# Core Generation Specs — Existing Categories

This pack defines **how to generate** the existing core output categories:
- Story
- Evidence
- Identification (and subcategories)
- Functioning (and subcategories)
- Actions (and subcategories)

These specs define depth, tone, constraints, and failure modes.
