# Identification Generation Spec

Subcategories:
- Ego
- Persona
- Shadow
- Shadow Virtue
- Feeling Function
- Eros Axis

Rules:
- Describe lived behavior
- Include cost and function
- Avoid moral judgment
